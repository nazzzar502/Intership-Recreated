namespace InternshipTest
{
    public class Knowledge
    {
        public Knowledge(int level)
        {
            //TODO: Implementation is needed
        }
    }
}
