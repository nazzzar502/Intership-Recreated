namespace InternshipTest.Person
{
    public class Student
    {
        public Student(string name)
        {
            //TODO: Implementation is needed
        }

        public void SetKnowledge(Knowledge knowledge)
        {
            //TODO: Implementation is needed
        }
    }
}