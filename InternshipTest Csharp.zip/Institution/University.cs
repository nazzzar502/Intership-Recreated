using InternshipTest.Person;

namespace InternshipTest.Institution
{
    public class University
    {
        public University(string name)
        {
            //TODO: Implementation is needed  
        }

        public void AddStudent(Student student)
        {
            //TODO: Implementation is needed
        }
    }
}
