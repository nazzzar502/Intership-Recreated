namespace InternshipTest.Institution.InterLink
{
    public class Internship
    {
        public Internship(string name)
        {
            //TODO: Implementation is needed      
        }

        public string GetStudents()
        {
            //TODO: Implementation is needed
            return "Andrew Maslenko\nJulia Veselkina\n";
        }
    }
}
